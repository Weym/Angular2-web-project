/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { DataFilterPipe } from './data-filter.pipe';

describe('Pipe: DataFilter', () => {
  it('create an instance', () => {
    let pipe = new DataFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
