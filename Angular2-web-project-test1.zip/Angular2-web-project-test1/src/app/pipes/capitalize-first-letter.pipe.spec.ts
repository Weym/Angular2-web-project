/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { CapitalizeFirstLetterPipe } from './capitalize-first-letter.pipe';

describe('Pipe: CapitalizeFirstLetter', () => {
  it('create an instance', () => {
    let pipe = new CapitalizeFirstLetterPipe();
    expect(pipe).toBeTruthy();
  });
});
