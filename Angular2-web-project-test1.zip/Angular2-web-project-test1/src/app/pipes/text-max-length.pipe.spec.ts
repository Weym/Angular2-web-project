/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { TextMaxLengthPipe } from './text-max-length.pipe';

describe('Pipe: TextMaxLength', () => {
  it('create an instance', () => {
    let pipe = new TextMaxLengthPipe();
    expect(pipe).toBeTruthy();
  });
});
