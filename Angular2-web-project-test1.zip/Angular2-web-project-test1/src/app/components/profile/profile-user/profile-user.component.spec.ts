/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { ProfileUserComponent } from './profile-user.component';

describe('Component: ProfileUser', () => {
  it('should create an instance', () => {
    let component = new ProfileUserComponent();
    expect(component).toBeTruthy();
  });
});
