/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { ProfileHostComponent } from './profile-host.component';

describe('Component: ProfileHost', () => {
  it('should create an instance', () => {
    let component = new ProfileHostComponent();
    expect(component).toBeTruthy();
  });
});
