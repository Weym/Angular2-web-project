/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { ProfileComponent } from './profile.component';

describe('Component: Profile', () => {
  it('should create an instance', () => {
    let component = new ProfileComponent();
    expect(component).toBeTruthy();
  });
});
