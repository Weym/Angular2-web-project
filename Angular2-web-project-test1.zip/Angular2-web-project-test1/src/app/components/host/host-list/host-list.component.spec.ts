/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { HostListComponent } from './host-list.component';

describe('Component: HostList', () => {
  it('should create an instance', () => {
    let component = new HostListComponent();
    expect(component).toBeTruthy();
  });
});
