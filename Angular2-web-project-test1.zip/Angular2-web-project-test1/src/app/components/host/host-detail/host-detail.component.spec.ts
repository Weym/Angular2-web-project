/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { HostDetailComponent } from './host-detail.component';

describe('Component: HostDetail', () => {
  it('should create an instance', () => {
    let component = new HostDetailComponent();
    expect(component).toBeTruthy();
  });
});
