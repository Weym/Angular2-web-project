import { Component } from '@angular/core';

@Component({
  selector: 'app-pages-start',
  template: `
    <p>
      Please select a Page! 
    </p>
  `,
  styles: []
})
export class HostStartComponent {

}
