/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { HostItem2Component } from './host-item2.component';

describe('Component: HostItem2', () => {
  it('should create an instance', () => {
    let component = new HostItem2Component();
    expect(component).toBeTruthy();
  });
});
