export class Image {
  constructor(public url: string, public title:string) {}
}
