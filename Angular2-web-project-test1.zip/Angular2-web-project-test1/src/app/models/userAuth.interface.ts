export interface UserAuth {
    email: string;
    password: string;
    confirmPassword?: string;
}
